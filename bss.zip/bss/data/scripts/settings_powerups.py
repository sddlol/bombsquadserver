#PCMODDER ~ AVAROHANA
#
#contains powerup box settings only
#use accordingly
#
#
modded_powerups = False
#
vanilla = True
#
grav = False
#
#
#powerup emition terms
#
powIce = False
#
powSplint = False
#
powSlime = False
#
powSweat = False
#
#
#special pwp commands / effects
#
powExplo = False
#
flash = False
#
powerupName = True
#
animate = False
#
powerupShield = False
#
discoLights = False
#
powerupTimer = True
#
lightning = True
#
powerup_text = True
#
#
