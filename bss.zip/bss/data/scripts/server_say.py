# -*- coding: utf-8 -*-
from __future__ import absolute_import

def say(msg):
    try:
        if msg is None:
            return
        # py2: to utf-8 bytes
        try:
            if isinstance(msg, unicode):
                s = msg.encode('utf-8')
            else:
                s = str(msg)
        except Exception:
            s = str(msg)

        open('data/scripts/server_say_queue.txt', 'wb').write(s)
        open('data/scripts/server_say_queue.flag', 'wb').write('1')
    except Exception:
        pass