# -*- coding: utf-8 -*-
# BombSquad 1.4.x / Python2-friendly members list module.
# This version persists changes by rewriting THIS FILE (membersID.py).

from __future__ import absolute_import

import os
import re

# -------------------------
# Public flags/lists (other scripts import these)
# -------------------------

# If True: everyone treated as admin/owner in checks that use it.
allAdmins = False

owners = ['pb-IF4DXmUpJg==', 'pb-IF4sUVcqDQ==']

admins = ['pb-IF4DXmUpJg==', 'pb-IF4sUVcqDQ==', 'pb-IF4OUhcnAw==', 'pb-IF4zUVYxKQ==', 'pb-IF4wXhUCVw==', 'pb-IF4VUEMqLg==', 'pb-IF4UUVVaFQ==']
vips = []

members = []

# Players who are rejected/banned/etc (some scripts check this)
rejected = []

# Some mods reference members_count (keep it to avoid AttributeError)
members_count = ['pb-IF4sUVcqDQ==', 'pb-IF4zUVYxKQ==', 'pb-IF4DXmUpJg==', 'pb-IF4jXmInVw==', 'pb-IF4uXhc9Lg==', 'pb-IF4wXhUCVw==', 'pb-IF4PXmYoVQ==', 'pb-IF4DXhgyAw==', 'pb-IF40XmUhDQ==', 'pb-IF4GUWsRBg==', 'pb-IF5WUE8HXQ==', 'pb-IF4qXmFeCw==', 'pb-IF4BV0kZNw==', 'pb-IF5VXmgOVQ==', 'pb-IF4dUFYKCw==', 'pb-IF5TXmgMXQ==', 'pb-IF4iUnUeAg==', 'pb-IF4lV1onAQ==', 'pb-IF4DUUgdJg==', 'pb-IF4VUEMqLg==', 'pb-IF4eUmo5PQ==']


# -------------------------
# Internal helpers
# -------------------------

_ALLOWED_KEYS = ('owners', 'admins', 'vips', 'members', 'rejected', 'members_count', 'allAdmins')

def _as_str(x):
    """Normalize pb-id to plain str in py2 (ascii-safe)."""
    try:
        # py2 unicode type exists
        if isinstance(x, unicode):
            return x.encode('utf-8')
    except Exception:
        pass
    try:
        return str(x)
    except Exception:
        return ''


def _dedupe_list(seq):
    """Deduplicate preserving order."""
    out = []
    seen = set()
    for it in seq:
        s = _as_str(it)
        if not s:
            continue
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _this_file_path():
    # __file__ is present when imported normally.
    try:
        return __file__
    except Exception:
        return None


def _rewrite_assignment(lines, key, value_repr):
    """
    Replace (or insert) a top-level assignment like:
        key = [...]
    """
    # Match: beginning of line, optional spaces, key, spaces, =, rest
    pat = re.compile(r'^(\s*)' + re.escape(key) + r'\s*=\s*.*$')
    for idx, ln in enumerate(lines):
        if pat.match(ln):
            indent = pat.match(ln).group(1) or ''
            lines[idx] = indent + key + ' = ' + value_repr + '\n'
            return True

    # If not found, append at end with newline
    if lines and not lines[-1].endswith('\n'):
        lines[-1] = lines[-1] + '\n'
    lines.append(key + ' = ' + value_repr + '\n')
    return True


def _persist_to_self(key, value):
    p = _this_file_path()
    if not p:
        return False

    # Read file as bytes then decode forgivingly (py2)
    try:
        raw = open(p, 'rb').read()
    except Exception:
        return False

    try:
        txt = raw.decode('utf-8', 'ignore')
    except Exception:
        try:
            txt = raw.decode('latin-1', 'ignore')
        except Exception:
            return False

    lines = txt.splitlines(True)  # keep line endings

    # Replace assignment line
    ok = _rewrite_assignment(lines, key, repr(value))

    if not ok:
        return False

    new_txt = ''.join(lines)
    try:
        open(p, 'wb').write(new_txt.encode('utf-8'))
    except Exception:
        return False

    return True


# -------------------------
# Public API used by cheatCmd (do NOT rename)
# -------------------------

def persist(key, value):
    """
    Update in-memory globals and write changes back to membersID.py.
    Called by cheatCmd: MID.persist('admins', updated_admins)
    """
    if key not in _ALLOWED_KEYS:
        return False

    global allAdmins, owners, admins, vips, members, rejected, members_count

    if key == 'allAdmins':
        allAdmins = bool(value)
        return _persist_to_self('allAdmins', allAdmins)

    # Normalize lists
    new_list = _dedupe_list(value)

    if key == 'owners':
        owners = new_list
    elif key == 'admins':
        admins = new_list
    elif key == 'vips':
        vips = new_list
    elif key == 'members':
        members = new_list
    elif key == 'rejected':
        rejected = new_list
    elif key == 'members_count':
        members_count = new_list

    return _persist_to_self(key, new_list)


# Convenience helpers (optional)
def add_owner(pb_id):
    lst = _dedupe_list(owners + [_as_str(pb_id)])
    return persist('owners', lst)

def add_admin(pb_id):
    lst = _dedupe_list(admins + [_as_str(pb_id)])
    return persist('admins', lst)

def add_vip(pb_id):
    lst = _dedupe_list(vips + [_as_str(pb_id)])
    return persist('vips', lst)

def add_member(pb_id):
    lst = _dedupe_list(members + [_as_str(pb_id)])
    return persist('members', lst)

def add_rejected(pb_id):
    lst = _dedupe_list(rejected + [_as_str(pb_id)])
    return persist('rejected', lst)

def remove_owner(pb_id):
    s = _as_str(pb_id)
    return persist('owners', [x for x in owners if _as_str(x) != s])

def remove_admin(pb_id):
    s = _as_str(pb_id)
    return persist('admins', [x for x in admins if _as_str(x) != s])

def remove_vip(pb_id):
    s = _as_str(pb_id)
    return persist('vips', [x for x in vips if _as_str(x) != s])

def remove_member(pb_id):
    s = _as_str(pb_id)
    return persist('members', [x for x in members if _as_str(x) != s])

def remove_rejected(pb_id):
    s = _as_str(pb_id)
    return persist('rejected', [x for x in rejected if _as_str(x) != s])


def reload_self():
    """
    Reload values by re-importing this module file contents into current globals.
    (Not strictly required, but some scripts call it.)
    """
    # Since we're self-modifying, simplest is to just return True.
    return True