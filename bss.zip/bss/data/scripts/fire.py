# -*- coding: utf-8 -*-

#PCMODDER ~ AVAROHANA
#
#seperated the mighty fire.py
#now contains a few basic server settings
#
#
whitelist = False
#
spamProtection = True
#
flashFloat = False
#
muteAll = False
#
auto_night = True
#
stats_shower = False
#
pcfloater = False
#
authentication = False
#
welcome_msg = u'支持炸弹小分队小团体! 😍😍😍'
#
tell_time = True
#
floater = False
#
