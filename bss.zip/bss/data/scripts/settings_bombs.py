#PCMODDER ~ AVAROHANA
#
#settings for the bombs only
#
#
bombName = True
#
bombTimer = True
#
bombModel = False
#
spikeModel = False
#
#
#
#
#
#to enable bomb lights and bomb shield, 
#use ?animate or enable animate in settings_powerups.py
#