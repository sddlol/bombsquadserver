#PCMODDER ~ AVAROHANA
#
#
#settings for spaz/player
#dont change the order of the list
#
#
pwp = False
#
nameP = False
#
#for default gameplay
#
defaultBoxingGloves = False
#
defaultShields = False
#
#special spaz/player gameplay
#
hp = True
#
tag = False
#
colory = False
#
randomChar = False
#
punchFlash = False
#
#
#spaz/player character ovveride
#use one at a time ~ commands
#
#
rchar = False
#
frosty = False
#
wizard = False
#
ali = False
#
santa = False
#
robot = False
#
pengu = False
#
pixie = False
#
ninja = False
#
#
#defualt bomb override
#use one at a time ~ commands
#
#
impact_bomb = False
#
sticky_bomb = False
#
ice_bomb = False
#
spike_bomb = False
#
shock_wave = False
#
knock_bomb = False
#
spaz_bomb = False
#
glue_bomb = False
#
#
#
#
#
#

