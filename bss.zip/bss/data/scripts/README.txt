安装说明（BombSquad 1.4.155 / Python2.7）

本包把 membersID 的数据改为写入 members_data.json（同目录），
不再在运行时改 membersID.py 本体；因此不会出现缩进/写坏文件问题。

包含文件：
- membersID.py   (JSON 稳定版)
- cheatCmd.py    (适配 JSON：/admin /vip /member 立刻生效 + 自动读取 JSON)
- bsLobby.py     (适配 JSON：不再改 membersID.py，本地保存 authentication/verification/members_count)

安装：
1) 备份 data/scripts 下原文件：
   - membersID.py
   - cheatCmd.py
   - bsLobby.py
2) 覆盖替换为本包文件（放到 data/scripts）
3) 删除旧的 .pyc（强烈建议）：
   - membersID.pyc
   - cheatCmd.pyc
   - bsLobby.pyc
4) 重启一次服务器（只需要这一次）
5) 启动后会自动生成 data/scripts/members_data.json

热更新：
- 你可以直接编辑 members_data.json（比如往 owners 里加自己的 pb-id），保存后无需重启：
  cheatCmd 的 checkOwner/checkAdmin 会在每次使用命令前自动 maybe_reload()。
- /admin /vip /member 修改后会立即写入 members_data.json 并立刻生效。

注意：
- /admin 仍然需要 owner 权限（owners 列表或 allAdmins=True）。
