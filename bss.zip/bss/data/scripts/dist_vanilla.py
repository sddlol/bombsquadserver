#PCMODDER ~ AVAROHANA
#
#powerup distribution for vanilla
#works only if vailla dist enabled
#
#
#
vanilla_dist = (('tripleBombs',3),
                ('iceBombs',3),
                ('punch',0),
                ('impactBombs',3),
                ('landMines',2),
                ('stickyBombs',3),
                ('shield',0),
                ('health',1),
                ('curse',1))