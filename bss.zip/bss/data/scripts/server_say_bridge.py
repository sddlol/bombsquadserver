# -*- coding: utf-8 -*-
from __future__ import absolute_import

import os
import bs
import bsInternal

_FLAG = os.path.join(bs.getEnvironment()['systemScriptsDirectory'], 'server_say_queue.flag')
_MSG  = os.path.join(bs.getEnvironment()['systemScriptsDirectory'], 'server_say_queue.txt')

def _tick():
    try:
        if os.path.exists(_FLAG):
            try:
                data = open(_MSG, 'rb').read()
            except Exception:
                data = ''
            try:
                os.remove(_FLAG)
            except Exception:
                pass

            if data:
                try:
                    msg = data.decode('utf-8', 'ignore').strip()
                except Exception:
                    try:
                        msg = unicode(data).strip()
                    except Exception:
                        msg = ''
                if msg:
                    try:
                        bsInternal._chatMessage(msg)
                    except Exception:
                        pass
    except Exception:
        pass

    # 轻量轮询：每 300ms 看一次，有消息才发
    try:
        bs.gameTimer(300, _tick)
    except Exception:
        pass

# start
try:
    bs.gameTimer(300, _tick)
except Exception:
    pass