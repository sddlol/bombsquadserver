# place any of your own overrides here.
# see bombsquad_server for details on what you can override
# examples (uncomment to use):
config['partyName'] = '🇨🇳《随风飘姚1.7新版单挑服QQ群:1081588862》🇨🇳☯2026马年大吉🎉🥳'
# config['sessionType'] = 'teams'
config['maxPartySize'] = 2026
config['port'] = 43211
config['playlistCode'] = 485669
